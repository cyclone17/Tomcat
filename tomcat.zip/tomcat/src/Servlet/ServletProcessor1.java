package Servlet;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLStreamHandler;
import javax.servlet.Servlet;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class ServletProcessor1
{
	public void process(Request request, Response response)
	{
		String uri = request.getUri();
		String surl;
		
		if(uri.indexOf("?")>=0)
			surl = uri.substring(uri.lastIndexOf("/"),uri.indexOf("?"));
		else
			surl = uri.substring(uri.lastIndexOf("/"));
		//System.out.println(surl);
		String servletName =new XMLUtil().getServletName(surl) ;
		//System.out.println(servletName);
		URLClassLoader loader = null;
		try
		{
			// create a URLClassLoader
			URL[] urls = new URL[1];
			URLStreamHandler streamHandler = null;
			File classPath = new File(Response.WEB_ROOT);
			// the forming of repository is taken from the
			// createClassLoader method in
			// org.apache.catalina.startup.ClassLoaderFactory
			String repository = (new URL("file", null, classPath.getCanonicalPath() + File.separator)).toString();
			// the code for forming the URL is taken from
			// the addRepository method in
			// org.apache.catalina.loader.StandardClassLoader.
			urls[0] = new URL(null, repository, streamHandler);
			loader = new URLClassLoader(urls);
		}
		catch (IOException e)
		{
			System.out.println(e.toString());
		}
		Class myClass = null;
		try
		{
	
			System.out.println(servletName);
		
			myClass = loader.loadClass(servletName);
		}
		catch (ClassNotFoundException e)
		{
			System.out.println(e.toString());
		}
		Servlet servlet = null;
		try
		{
			//��һ�·��䣬��ʼ��һ��ʵ����Ȼ��������servlet��service������
			servlet = (Servlet) myClass.newInstance();
			servlet.service((ServletRequest) request, (ServletResponse) response);
		}
		catch (Exception e)
		{
			System.out.println(e.toString());
		}
		catch (Throwable e)
		{
			System.out.println(e.toString());
		}
	}

	public void process2(Request request, Response response){
		 
    	//�õ�·������ȡ����Ӧjsp����
        String uri = request.getUri();  
        String jspname = uri.substring(uri.lastIndexOf("/") + 1);
        String[] names = jspname.split("\\.");
        File file = new File(System.getProperty("user.dir") + File.separator + "WebRoot" + File.separator + jspname);
        
        //��jsp�ļ�����ʱת��Ϊservlet�ļ�
        if(file.exists()){
        	try {
				Jsp.read(jspname);
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
        }else{
        	//�Ҳ����ļ�ʱ����404��Ϣ
        	String errorMessage = "HTTP/1.1 404 File Not Found\r\n" + "Content-Type: text/html\r\n" + "Content-Length: 23\r\n" + "\r\n" + "<h1>File Not Found</h1>";  
            try {
				response.output.write(errorMessage.getBytes());
			} catch (IOException e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
            return; 
        }

		File jsp1 = new File(System.getProperty("user.dir") + File.separator 
    			+ "bin" + File.separator + "Servlet" + File.separator + names[0] + "_jsp.class");
		while(!jsp1.exists()){}
		
		File jsp2 = new File(System.getProperty("user.dir") + File.separator 
    			+ "src" + File.separator + "Servlet" + File.separator + names[0] + "_jsp.java");
		while(!jsp2.exists()){}
		
        URLClassLoader loader = null;
        try  
        {  
            //����·������Ӧ������
            URL[] urls = new URL[1];  
            File classPath = new File(System.getProperty("user.dir") + File.separator + "src" + File.separator);
            //������·��תΪ��Ӧ��ʽ
            URL url = classPath.toURI().toURL();
            urls[0]=url;
            //���ظ�·��
            loader = new URLClassLoader(urls);  
        }  
        catch (IOException e)  
        {  
            System.out.println(e.toString());  
        }  
        Class<?> myClass = null; 
        try  
        {
            //������Ӧ·���µ���Ӧ��  
            myClass = loader.loadClass("Servlet." + names[0] + "_jsp");
        }  
        catch (ClassNotFoundException e)  
        {  
        	//�಻����������ʱ����404��Ϣ
            String errorMessage = "HTTP/1.1 404 File Not Found\r\n" + "Content-Type: text/html\r\n" + "Content-Length: 23\r\n" + "\r\n" + "<h1>File Not Found</h1>";  
            try {
				response.output.write(errorMessage.getBytes());
			} catch (IOException e1) {
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
            System.out.println("nothing left!");
            return; 
        }  
        Servlet servlet = null;  
        try  
        {  
            //������Ӧ���ಢʵ������Ȼ�����servlet��init,service������  
            servlet = (Servlet) myClass.newInstance();
            servlet.service((ServletRequest) request, (ServletResponse) response);
        }  
        catch (Exception e)  
        {  
            System.out.println(e.toString());  
        }  
        catch (Throwable e)  
        {  
            System.out.println(e.toString());  
        }  
	}
}
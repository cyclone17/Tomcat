package Servlet;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
public class Jsp {
	
	public static final String WEB_ROOT = System.getProperty("user.dir")+File.separator+"WebRoot";
	
	public static void read(String uri) throws IOException
	{
		FileInputStream fis=null;
		String content = "";
		try
		{
				System.out.print(WEB_ROOT);
				File file = new File(WEB_ROOT,uri);
				StringBuilder sb = new StringBuilder();
				String s ="";
				BufferedReader br = new BufferedReader(new FileReader(file));
				
				while((s =br.readLine())!=null){
					sb.append(s+"\n");
				}
				br.close();
				content = sb.toString();
		}catch (Exception e)  
        {  
        	//�Ҳ����ļ�ʱ����
            content = "!BIAOGIA! HTTP/1.1 404 File Not Found\r\n" + "Content-Type: text/html\r\n" + "Content-Length: 23\r\n" + "\r\n" + "<h1>File Not Found</h1>";  
        }  
        finally  
        {  
        	//�ر�����
            if (fis != null)  
                fis.close();  
        }  
        //��jsp��ʽ��Ϊservlet
        change(content, uri);
	}
	
	public static void change(String file,String filename) throws IOException
	{
		StringBuffer content = new StringBuffer();
		String[] name = filename.split("\\.");
		content.append("package Servlet;"+"\r\n");
		int p = file.indexOf("%>",file.lastIndexOf("<%@"));
		p +=2;
		int p1 = 0;
    	int p2 = 0;
    	int p3 = 0;
    	int p4 = 0;
    	
    	while(true){
    		p1 = file.indexOf("import",p1);
    		if(p1==-1||p1>p){
    			break;
    		}else{
    			p2=file.indexOf("\"",p1);
    			p3 = file.indexOf("\"", p2+1);
    			p4 = file.indexOf(";", p1);
    			if(p2<p3){
    				String[] datas = file.substring(p2+1,p3).split(",");
    				for(int i=0;i<datas.length;i++){
    					content.append("import "+datas[i]+";\r\n");
    				}
    			}
    		}
    		p1=p3+1;
    	}
    	content.append("import javax.servlet.*;" + "\r\n"
    			+ "import java.io.IOException;" + "\r\n"
    			+ "import java.io.PrintWriter;" + "\r\n"
    			+ "public class " 
    			+ name[0] + "_jsp" 
    			+ " implements Servlet {" + "\r\n"
    			+ "public void init(ServletConfig config) throws ServletException {}" + "\r\n"
    			+ "public void service(ServletRequest request, ServletResponse response)" + "\r\n"
    			+ "throws ServletException, IOException {" + "\r\n"
    			+ "PrintWriter out = response.getWriter();\r\n");
    	
    	//���Ӿ�����ļ�����
    	content.append("out.println(\"");
    	int p5 = 0;
    	int p6 = 0;
    	int j;
    	while(true){
    		p5 = file.indexOf("<%=",p);
    		p6 = file.indexOf("<%",p);
    		if(p6 == -1){
    			String[] datas =file.substring(p).split("\n");
    			for(int i=0;i<datas.length;i++){
    				String[] data2 = datas[i].split("\"");
    				for(j=0;j<data2.length-1;j++){
    					content.append(data2[j]+"\\\"");
    				}
    				content.append(data2[j]+"\");\r\nout.println(\"");
    			}
    			content.append("\");");
    			break;
    			//dddddddddddddddd
    		}else{
    			String[] datas = file.substring(p,p6).split("\n");
    			for(int i=0; i<datas.length; i++){
    				String[] datas2 = datas[i].split("\"");
    				for(j=0; j<datas2.length-1; j++){
    					content.append(datas2[j] + "\\\"");
    				}
    				content.append(datas2[j] + "\");\r\nout.println(\"");
    			}
    			content.append("\");\r\n");
    			p = file.indexOf("%>", p6);
    			//����һ����ǩ��<%ʱ����
        		if(p5 == -1 || p6< p5){
        			String[] datas12 = file.substring(p6+2, p).split("\n");
        			for(int i=0; i<datas12.length; i++){
        				content.append(datas12[i] + "\r\n");
        			}
        	    	content.append("out.println(\"");
        	    //����ǩ��<%=ʱ����
        		}else {
        			String[] datas12 = file.substring(p5+3, p).split("\n");
        			for(int i=0; i<datas12.length; i++){
        				content.append("out.println(" + datas12[i] + ");\r\n");
        			}
        	    	content.append("out.println(\"");
        		}	
        		p += 2;
    		}
    	}
    	//������������
    	content.append("}" + "\r\n"
    			+ "public void destroy() {}" + "\r\n"
    			+ "public String getServletInfo() {" + "\r\n"
    			+ "return null;" + "\r\n"
    			+ "}" + "\r\n"
    			+ "public ServletConfig getServletConfig() {" + "\r\n"
    			+ "return null;}}");
    	//�����ݴ��䵽�ļ�
    	out(filename, content);
	}
	
	private static void out(String filename,StringBuffer content){
		String[] jspname = filename.split("\\."); 
    	File jsp = new File(System.getProperty("user.dir") + File.separator 
    			+ "src" + File.separator + "Servlet" + File.separator + jspname[0] + "_jsp.java");
		try {
			//���ļ������ݴ����ļ�
			FileOutputStream fos = new FileOutputStream(jsp);
            PrintWriter pw = new PrintWriter(fos);
            pw.write(content.toString().toCharArray());
            pw.flush();
            pw.close();
            fos.close();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
}
